// myapp/static/js/myjavascript.js
function myFunction() {
    document.getElementById("demo").innerHTML = "Hello World!";
}
