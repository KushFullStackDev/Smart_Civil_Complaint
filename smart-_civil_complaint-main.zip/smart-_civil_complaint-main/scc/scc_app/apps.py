from django.apps import AppConfig


class SccAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'scc_app'
